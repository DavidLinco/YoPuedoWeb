# Yo Puedo Web — prototipo HTML/CSS/JavaScript

## Cómo abrirlo
Abre `index.html` en Chrome, Firefox o Edge. No requiere instalar paquetes, internet, backend ni pasarela de pagos. Si deseas usar un servidor local, desde esta carpeta ejecuta `python -m http.server 8000` y visita `http://localhost:8000`.

## Acceso de demostración
En la portada elige «Iniciar sesión», «Soy Apoderado» o «Soy Fonoaudiólogo». Introduce **cualquier correo ficticio con formato válido** y una contraseña ficticia de al menos seis caracteres (por ejemplo `demo@ejemplo.cl` y `demo123`). No utilices datos personales reales. La interfaz no transmite credenciales. Para el fonoaudiólogo se muestran únicamente formularios y aviso de panel pendiente.

## Navegación
Niño: Inicio → Juegos → Respira (5 opciones, construcción) / Repite (maqueta parcial) / Cuenta una historia (5 actividades, avance manual) / Sala segura. Menú lateral: Mi progreso, Recompensas, Perfil.

Apoderado: Inicio → Actividades / Mensajes / Perfil → Planes → pago ficticio. En el perfil infantil los controles de cuenta y pagos están deshabilitados.

## Recursos gráficos
`assets/referencia-01.webp` a `assets/referencia-29.webp` son las **29 capturas de Figma incluidas en el DOCX**, no los PNG originales de los ZIP. Los recortes `hero-chispa.webp`, `sala-segura.webp`, `construccion.webp` y `sidebar-space.webp` proceden de esas capturas. Las imágenes originales de Chispa y demás recursos no estaban incluidos individualmente en este archivo adjunto: para máxima fidelidad visual conviene sustituir los recortes por los PNG originales de los ZIP.

## Alcance y limitaciones
- Ejercicios de Cuenta historias: 5 actividades, con 3 fases de ejemplo (Cuenta tu día tiene 5 preguntas); avance manual y micrófono simulado, sin captura ni análisis de audio.
- Respira: cinco opciones con pantalla en construcción.
- Repite: maqueta parcial, porque el informe describe principalmente Cuenta historias y Respira, aunque las capturas incluyen Repite.
- Sala segura: imagen de referencia y preguntas simuladas.
- Progreso y Ki: cifras ficticias, coherentes dentro de la demo, almacenadas en `localStorage`.
- Suscripción: formulario de **datos ficticios** (4 dígitos, MM/AA y 3 dígitos), sin pago ni almacenamiento de tarjeta.
- Chats: ventanas con mensajes ficticios, sin mensajería real.
- Los 29 PNG de referencia son capturas de pantalla, no assets editables. El Figma en línea no fue verificado en esta implementación.

## Checklist manual
1. Ingresar como niño, navegar por las 5 secciones.
2. Abrir Cuenta historias y probar las 5 actividades y Avanzar.
3. Abrir cada opción de Respira y comprobar Volver.
4. Probar Sala segura, progreso, recompensas y nombre editable.
5. Comprobar que los controles de pago están deshabilitados en perfil infantil.
6. Ingresar como apoderado, abrir chats, Planes, cancelar y confirmar pago simulado.
7. Verificar cambio a Premium en Perfil y Planes; volver a Gratuito.
8. Probar formularios de fonoaudiólogo, móvil, teclado y cierre de modales.

## Pendientes para fidelidad 1:1
Incorporar los ZIP de assets originales, comparar cada pantalla a tamaño de Figma, completar fases literales, pantallas de Repite, detalles del apoderado y definición del panel del especialista.


## Rediseño con recursos originales
Se incorporaron los 74 elementos del ZIP facilitado por el equipo, sin alterar la ilustración original de Chispa. El manifiesto `assets/manifest.json` registra el nombre original y el nombre utilizado. La interfaz se abre localmente desde `index.html`. Las interacciones de voz y pagos siguen siendo simuladas.


### Indicador de actividades realizadas
En los selectores **Repite** y **Cuenta una historia**, las estrellas de cada fila fueron reemplazadas por un check verde (✓) que solo aparece después de completar todas las fases con el botón de avance. Las actividades de **Respira** permanecen sin check porque aún están en construcción. El estado se guarda en el navegador (localStorage) y se conserva al recargar.


### Corrección Cuenta una historia
- Se intercambiaron las ilustraciones de Cuenta tu día e Imita al personaje para corresponder a sus escenas.
- Todas las actividades de Cuenta una historia muestran puntos de avance por fase, con fase actual y total, igual que Repite. El avance sigue siendo manual.


## Tipografía
Los títulos y textos destacados usan Fredoka; los textos normales y pequeños usan Nunito. Las fuentes se cargan desde Google Fonts al disponer de conexión a Internet, con fuentes alternativas cuando se usa sin conexión.
